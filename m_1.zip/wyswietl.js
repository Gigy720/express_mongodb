const mongo=require("mongodb")
const express=require('express');

const app=express()
const port=5555;
const url='mongodb://127.0.0.1:27017'

const klient=new mongo.MongoClient(url)

//nmp install ejs --saves

klient.connect(err =>{
    if(err) console.log("brak polaczenie z serwerem");
})


const db=klient.db("uczniowie");
const pracownicy=db.collection("pracownicy")



app.set('view engine','ejs');


app.get("/",async (request,response)=>{
    let dane=await pracownicy.find().toArray();
    response.render('index.ejs',{a:dane})

})


app.listen(port,()=>{
    console.log("Serwer dziala");
})


