const mongo=require("mongodb")
const express=require('express');
const { request, response } = require("express");

const app=express()
const port=5555;
const url='mongodb://127.0.0.1:27017'

const klient=new mongo.MongoClient(url)

klient.connect(err =>{
    if(err) console.log("brak polaczenie z serwerem");
})

const db=klient.db("uczniowie");
const pracownicy=db.collection("pracownicy")


app.get("/",(request,response)=>{

    response.sendFile(__dirname+"\\index.html")
    response
    const {id,imie,nazwisko,stanowisko}=request.query

   
    if(id && imie && nazwisko && stanowisko)
    {
       
        pracownicy.insertOne({id:Number(id),imie:imie,nazwisko:nazwisko,stanowisko:stanowisko})
    }
})


app.listen(port,()=>{
    console.log("Serwer dziala");
})


