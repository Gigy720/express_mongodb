const { response } = require('express')
const express=require('express')
const mongo=require('mongodb')
const bodyparser=require("body-parser")
const bodyParser = require('body-parser')

const app=express()

const port=5555;
const uri="mongodb://127.0.0.1:27017"

const klient=new mongo.MongoClient(uri)

klient.connect(err=>{
    if(err) console.log("Blad polaczenia z baza");
})

const db=klient.db("uczniowie")
const pracownicy=db.collection("pracownicy")


app.get("/",(request,response)=>{
    response.sendFile(__dirname+"\\index.html")
})

app.get("/dodaj.html",(request,response)=>{
    response.sendFile(__dirname+"\\dodaj.html")
})

app.use(bodyParser.json())
app.use(bodyparser.urlencoded({extended:true}))

app.post("/formularz",async (request,response)=>{

    const {imie,nazwisko,stanowisko}=request.body
    id=await pracownicy.countDocuments();

    pracownicy.insertOne({id:Number(id)+1,imie:`${imie}`,nazwisko:`${nazwisko}`,stanowisko:`${stanowisko}`})

    response.send("Dane zostaly wygenerowane <br><a href='/'>powrot</a>")
})

app.set("view engine","ejs")

app.get("/pokaz.html",async (request,response)=>{
    console.log(await pracownicy.countDocuments());
    let dane=await pracownicy.find().toArray()
    response.render("index.ejs",{a:dane})
})

app.get("/aktualizacja.html",(request,response)=>{
    response.sendFile(__dirname+"\\aktualizacja.html")
})

app.post("/aktualizacja-danych",(request,response)=>{
    const {id,imie,nazwisko,stanowisko}=request.body
    
    pracownicy.updateOne(  {id:Number(id)},{$set:{imie:`${imie}`,nazwisko:`${nazwisko}`,stanowisko:`${stanowisko}`}}     )
    response.send("<a href='/'>Powrot</a>")

})
app.listen(port,()=>{
    console.log("Serwer dziala");
})
